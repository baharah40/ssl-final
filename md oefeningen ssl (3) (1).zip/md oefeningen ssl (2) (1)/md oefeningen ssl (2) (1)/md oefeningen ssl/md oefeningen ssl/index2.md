| wat can binnen een SSL |hoe can ik dat toevoegen?                      |   |
| :------------------- | :----------: | ----------:                       |
| Afbelding   | gewoon om de foto in dezelfde map te steken      |        |
| Linken               | zoals afbelding een link kunt ook direct invoegen   |      |
|Tabelen               | je kunt van een rechte stripje gebruiken       |        |

[dit is een link naar de eerste pagina](#([text](index.md)))